// initial color for Ellipse
let R = 255;
let G = 255;
let B = 255;
let T = 1;
// initial color for Rect
let RectR = 50;
let RectG = 0;
let RectB = 20;
let RectT = 1;

// initial position for small ellipse

let posX = (50, 50, 0, 0);

function setup(){
colorMode(RGB, 255, 255, 255, 1);
createCanvas(400,400);
frameRate(60);
}

function draw() {

// use background in draw to have realistic animations
  background(255, 255, 255, 1);
  fill(RectR, RectG, RectB, RectT);
  rect(50, 50, 300, 300);
  fill(R, G, B, T);
  ellipse(posX , 75, 10, 10);

  if(keyIsPressed === false){
    posX++;
    RectR = 0;
    RectG = 0;
    RectB = 0;
    RectT = 1;
  } else {
    RectR = 255;
    RectG = 255;
    RectB = 255;
    RectT = 1;
  }
  if(posX > width){
    posX = 50;
  
  }
}

function mouseClicked() {

// reset position of the small ellipse

  posX = (50, 50);

}
