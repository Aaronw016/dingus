

function setup() {
  createCanvas(400, 400);
  background(0, 26, 51, 1);
  strokeWeight(30);
}

function draw() {
  colorMode (RGB, 255, 255, 255, 1);
  background(0, 26, 51, 1);
  stroke(102);
  line(40, 0, 70, height);
  if (mouseIsPressed == true) {
    stroke(255, 100, 0, 1);
  }
  line(0, 70, width, 50);
  
  if (keyIsPressed) {
      stroke(100, 255, 0, 1);
    line (40, 0, 70, height);
  }
function draw() {
  for (var i= 20; i<400; i += 20){
    line(i, 0, i+i/2, 80);
  }
}
  
  
  
  
}