function setup() {
  createCanvas(400, 400);
   colorMode(RGB, 255, 255, 255, 1)
}

function draw() {
  background(75);
arc(350, 350, 200, 200, 0, TWO_PI);
  fill(100, 0, 100, .85)
  
line(200, 200, 250, 250);

line(105, 105, 150, 150)
  
  
  
  quad(100, 100, 85, 30, 69, 63, 30, 76);
  translate(50, 50);
  
stroke(0, 0, 0);
beginShape();
// Exterior part of shape, clockwise winding
vertex(-55, -50);
vertex(355, -50);
vertex(350, 402);
vertex(-250, 402);
// Interior part of shape, counter-clockwise winding
stroke(0, 0, 0)
beginContour();
vertex(-20, -20);
vertex(-20, 320);
vertex(320, 320);
vertex(320, -20);
endContour();
endShape(CLOSE);

  





  
  


  
}